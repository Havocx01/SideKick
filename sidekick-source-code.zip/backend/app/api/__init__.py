"""FastAPI routes."""
